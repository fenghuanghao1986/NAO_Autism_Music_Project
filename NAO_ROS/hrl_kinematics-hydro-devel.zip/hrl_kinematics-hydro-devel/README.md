hrl_kinematics
==============

ROS kinematics library for humanoid robots based on KDL: center of mass, (static) stability, and support polygon computations.
