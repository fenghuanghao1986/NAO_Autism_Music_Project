^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package nao_description
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.3 (2014-03-27)
------------------
* Fix `#17 <https://github.com/ros-nao/nao_robot/issues/17>`_: add dependency on sensor_msgs in nao_description

0.2.2 (2013-10-28)
------------------

0.2.1 (2013-10-25)
------------------
* [nao_description] Added missing include dirs in CMakeLists

0.2.0 (2013-10-25)
------------------
* Added base_footprint node to nao_description, publishes footprint according
  to REP-120 (based on previous node nao_remote/remap_odometry). Fixes Issue `#10 <https://github.com/ros-nao/nao_robot/issues/10>`_.
* Moved nao_description from nao_common to nao_robot

