nao_robot
=========

ROS stack for the Nao robot, see http://www.ros.org/wiki/nao_robot
